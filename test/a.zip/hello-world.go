package main

import (
	"log"
	"net/http"
	"github.com/DeedleFake/Go-PhysicsFS/physfs"
)

// func hello(w http.ResponseWriter, r *http.Request) {
// 	io.WriteString(w, fmt.Sprintf("%s %s", r.Method, r.URL))
// }

// func main() {
// 	http.HandleFunc("/", hello)
// 	http.ListenAndServe(":7890", nil)
// }

// type FileSystem interface {
//     Open(name string) (File, error)
// }

func main() {
	physfs.Init()
	physfs.Mount(".", "", true)
	log.Fatal(http.ListenAndServe(":8080", http.FileServer(physfs.FileSystem())))
	physfs.Deinit()
}
